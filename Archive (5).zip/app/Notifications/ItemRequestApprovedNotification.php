<?php

namespace App\Notifications;

use App\Models\ItemRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ItemRequestApprovedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public ItemRequest $request;

    public function __construct(ItemRequest $request)
    {
        $this->request = $request;
    }

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Item Request Approved')
            ->greeting("Hi {$notifiable->name},")
            ->line("Item request {$this->request->request_number} was approved.")
            ->action('View Request', route('branch-dashboard.inventory.item-requests', ['b_id' => $this->request->branch_id]));
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'item_request_approved',
            'item_request_id' => $this->request->id,
            'branch_id' => $this->request->branch_id,
            'branch_name' => $this->request->branch?->name,
            'message' => "Item request {$this->request->request_number} approved.",
            'action_url' => route('branch-dashboard.inventory.item-requests', ['b_id' => $this->request->branch_id]),
            'action_text' => 'View Request',
        ];
    }
}
